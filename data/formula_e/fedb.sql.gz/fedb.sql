-- MySQL dump 10.13  Distrib 5.1.73, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: fedb
-- ------------------------------------------------------
-- Server version	5.1.73

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `circuits`
--

DROP TABLE IF EXISTS `circuits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `circuits` (
  `circuitId` int(11) NOT NULL AUTO_INCREMENT,
  `circuitRef` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `location` varchar(255) DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `lat` float DEFAULT NULL,
  `lng` float DEFAULT NULL,
  `alt` int(11) DEFAULT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`circuitId`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `circuits`
--

LOCK TABLES `circuits` WRITE;
/*!40000 ALTER TABLE `circuits` DISABLE KEYS */;
INSERT INTO `circuits` VALUES (1,'beijing','Beijing Olympic Green Circuit','Beijing','China',39.9947,116.385,NULL,'http://en.wikipedia.org/wiki/Beijing_Olympic_Green_Circuit'),(2,'putrajaya','Putrajaya Street Circuit','Putrajaya','Malaysia',2.92583,101.688,NULL,'http://en.wikipedia.org/wiki/Putrajaya_Street_Circuit'),(3,'este','Punta del Este Street Circuit','Punta del Este','Uruguay',-34.9547,-54.9344,NULL,'http://en.wikipedia.org/wiki/Punta_del_Este_Street_Circuit'),(4,'madero','Puerto Madero Street Circuit','Buenos Aires','Argentina',-34.6147,-58.3575,NULL,'http://en.wikipedia.org/wiki/Puerto_Madero_Street_Circuit'),(5,'miami','Biscayne Bay','Miami','United States',25.7667,-80.2,NULL,'http://en.wikipedia.org/wiki/Downtown_Miami'),(6,'long_beach','Long Beach Street Circuit','California','United States',33.7664,-118.193,NULL,'http://en.wikipedia.org/wiki/Grand_Prix_of_Long_Beach#Formula_E'),(7,'tempelhof','Berlin Tempelhof Airport','Berlin','Germany',52.4736,13.4017,NULL,'http://en.wikipedia.org/wiki/Berlin_Tempelhof_Airport'),(8,'monaco','Circuit de Monaco','Monte-Carlo','Monaco',43.7347,7.42056,NULL,'http://en.wikipedia.org/wiki/Circuit_de_Monaco#FIA_Formula_E_Championship'),(9,'battersea','Battersea Park Circuit','London','UK',51.4793,-0.1573,NULL,'http://en.wikipedia.org/wiki/Battersea_Park#Formula_E_Street_Circuit'),(10,'tba','TBA','','',0,0,NULL,''),(11,'moscow','Moscow Street Circuit','Moscow','Russia',55.7497,37.6297,NULL,'http://en.wikipedia.org/wiki/Moscow_Street_Circuit');
/*!40000 ALTER TABLE `circuits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `constructorResults`
--

DROP TABLE IF EXISTS `constructorResults`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `constructorResults` (
  `constructorResultsId` int(11) NOT NULL AUTO_INCREMENT,
  `raceId` int(11) NOT NULL DEFAULT '0',
  `constructorId` int(11) NOT NULL DEFAULT '0',
  `points` float DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`constructorResultsId`)
) ENGINE=MyISAM AUTO_INCREMENT=111 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `constructorResults`
--

LOCK TABLES `constructorResults` WRITE;
/*!40000 ALTER TABLE `constructorResults` DISABLE KEYS */;
INSERT INTO `constructorResults` VALUES (1,1,1,26,NULL),(2,1,2,30,NULL),(3,1,3,15,NULL),(4,1,4,10,NULL),(5,1,5,14,NULL),(6,1,6,4,NULL),(7,1,7,2,NULL),(8,1,8,3,NULL),(9,1,9,0,NULL),(10,1,10,2,NULL),(11,2,3,29,NULL),(12,2,1,19,NULL),(13,2,8,30,NULL),(14,2,5,16,NULL),(15,2,4,8,NULL),(16,2,10,4,NULL),(17,2,6,0,NULL),(18,2,7,0,NULL),(19,2,2,0,NULL),(20,2,9,0,NULL),(21,3,8,31,NULL),(22,3,6,18,NULL),(23,3,1,17,NULL),(24,3,9,12,NULL),(25,3,3,10,NULL),(26,3,4,8,NULL),(27,3,5,6,NULL),(28,3,7,1,NULL),(29,3,2,3,NULL),(30,3,10,0,NULL),(31,4,10,25,NULL),(32,4,8,21,NULL),(33,4,6,15,NULL),(34,4,3,20,NULL),(35,4,4,10,NULL),(36,4,2,8,NULL),(37,4,7,5,NULL),(38,4,5,2,NULL),(39,4,1,0,NULL),(40,4,9,0,NULL),(41,5,8,25,NULL),(42,5,2,21,NULL),(43,5,1,17,NULL),(44,5,5,18,NULL),(45,5,6,12,NULL),(46,5,10,9,NULL),(47,5,3,4,NULL),(48,5,7,0,NULL),(49,5,4,0,NULL),(50,5,9,0,NULL),(51,6,6,25,NULL),(52,6,2,18,NULL),(53,6,1,18,NULL),(54,6,8,14,NULL),(55,6,4,10,NULL),(56,6,5,10,NULL),(57,6,10,6,NULL),(58,6,3,4,NULL),(59,6,7,1,NULL),(60,6,9,0,NULL),(61,7,8,36,NULL),(62,7,1,18,NULL),(63,7,6,19,NULL),(64,7,7,7,NULL),(65,7,5,10,NULL),(66,7,2,2,NULL),(67,7,10,2,NULL),(68,7,9,0,NULL),(69,7,4,0,NULL),(70,7,3,12,NULL),(71,8,5,40,NULL),(72,8,8,19,NULL),(73,8,6,14,NULL),(74,8,7,18,NULL),(75,8,2,6,NULL),(76,8,3,4,NULL),(77,8,9,2,NULL),(78,8,10,0,NULL),(79,8,1,0,NULL),(80,8,4,0,NULL),(81,9,6,25,NULL),(82,9,1,28,NULL),(83,9,7,15,NULL),(84,9,2,16,NULL),(85,9,10,14,NULL),(86,9,8,8,NULL),(87,9,5,0,NULL),(88,9,4,0,NULL),(89,9,3,0,NULL),(90,9,9,3,NULL),(91,10,8,34,NULL),(92,10,5,22,NULL),(93,10,2,15,NULL),(94,10,1,14,NULL),(95,10,6,12,NULL),(96,10,3,8,NULL),(97,10,7,1,NULL),(98,10,4,0,NULL),(99,10,9,0,NULL),(100,10,10,0,NULL),(101,11,3,27,NULL),(102,11,5,33,NULL),(103,11,4,12,NULL),(104,11,8,11,NULL),(105,11,1,8,NULL),(106,11,6,8,NULL),(107,11,10,4,NULL),(108,11,2,0,NULL),(109,11,9,0,NULL),(110,11,7,3,NULL);
/*!40000 ALTER TABLE `constructorResults` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `constructorStandings`
--

DROP TABLE IF EXISTS `constructorStandings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `constructorStandings` (
  `constructorStandingsId` int(11) NOT NULL AUTO_INCREMENT,
  `raceId` int(11) NOT NULL DEFAULT '0',
  `constructorId` int(11) NOT NULL DEFAULT '0',
  `points` float NOT NULL DEFAULT '0',
  `position` int(11) DEFAULT NULL,
  `positionText` varchar(255) DEFAULT NULL,
  `wins` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`constructorStandingsId`)
) ENGINE=MyISAM AUTO_INCREMENT=491 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `constructorStandings`
--

LOCK TABLES `constructorStandings` WRITE;
/*!40000 ALTER TABLE `constructorStandings` DISABLE KEYS */;
INSERT INTO `constructorStandings` VALUES (334,1,4,10,5,'5',0),(335,1,5,14,4,'4',0),(336,1,6,4,6,'6',0),(337,1,7,2,8,'8',0),(340,1,10,2,9,'9',0),(339,1,9,0,10,'10',0),(338,1,8,3,7,'7',0),(333,1,3,15,3,'3',0),(332,1,2,30,1,'1',0),(331,1,1,26,2,'2',1),(360,3,10,6,9,'9',0),(350,2,10,6,7,'7',0),(343,2,3,44,2,'2',1),(344,2,4,18,6,'6',0),(345,2,5,30,5,'5',0),(346,2,6,4,8,'8',0),(347,2,7,2,9,'9',0),(348,2,8,33,3,'3',0),(349,2,9,0,10,'10',0),(359,3,9,12,8,'8',0),(353,3,3,54,3,'3',1),(351,3,1,62,2,'2',1),(357,3,7,3,10,'10',0),(356,3,6,22,7,'7',0),(355,3,5,36,4,'4',0),(354,3,4,26,6,'6',0),(370,4,10,31,8,'8',1),(369,4,9,12,9,'9',0),(368,4,8,85,1,'1',1),(361,4,1,62,3,'3',1),(366,4,6,37,6,'6',0),(365,4,5,38,5,'5',0),(364,4,4,36,7,'7',0),(363,4,3,74,2,'2',1),(380,5,10,40,7,'7',1),(379,5,9,12,9,'9',0),(378,5,8,110,1,'1',2),(377,5,7,8,10,'10',0),(376,5,6,49,6,'6',0),(375,5,5,56,5,'5',0),(373,5,3,78,3,'3',1),(374,5,4,36,8,'8',0),(372,5,2,62,4,'4',0),(371,5,1,79,2,'2',1),(342,2,2,30,4,'4',0),(352,3,2,33,5,'5',0),(362,4,2,41,4,'4',0),(389,6,9,12,9,'9',0),(390,6,10,46,7,'7',1),(388,6,8,124,1,'1',2),(384,6,4,46,8,'8',0),(385,6,5,66,6,'6',0),(386,6,6,74,5,'5',1),(383,6,3,82,3,'3',1),(382,6,2,80,4,'4',0),(381,6,1,97,2,'2',1),(450,7,10,48,7,'7',1),(449,7,9,12,10,'10',0),(448,7,8,160,1,'1',3),(447,7,7,16,9,'9',0),(446,7,6,93,4,'4',1),(445,7,5,76,6,'6',0),(444,7,4,46,8,'8',0),(443,7,3,94,3,'3',1),(442,7,2,82,5,'5',0),(441,7,1,115,2,'2',1),(458,8,8,179,1,'1',3),(459,8,9,14,10,'10',0),(460,8,10,48,7,'7',1),(457,8,7,34,9,'9',0),(456,8,6,107,4,'4',1),(455,8,5,116,2,'2',1),(454,8,4,46,8,'8',0),(453,8,3,98,5,'5',1),(452,8,2,88,6,'6',0),(469,9,9,17,10,'10',0),(470,9,10,62,7,'7',1),(468,9,8,187,1,'1',3),(467,9,7,49,8,'8',0),(466,9,6,132,3,'3',2),(465,9,5,116,4,'4',1),(464,9,4,46,9,'9',0),(463,9,3,98,6,'6',1),(462,9,2,104,5,'5',0),(479,10,9,17,10,'10',0),(480,10,10,62,7,'7',1),(490,11,10,66,7,'7',1),(478,10,8,221,1,'1',4),(477,10,7,50,8,'8',0),(476,10,6,144,3,'3',2),(475,10,5,138,4,'4',1),(474,10,4,46,9,'9',0),(473,10,3,106,6,'6',1),(472,10,2,119,5,'5',0),(489,11,9,17,10,'10',0),(488,11,8,232,1,'1',4),(481,11,1,165,3,'3',1),(487,11,7,53,9,'9',0),(486,11,6,152,4,'4',2),(485,11,5,171,2,'2',1),(484,11,4,58,8,'8',0),(483,11,3,133,5,'5',2),(341,2,1,45,1,'1',1),(358,3,8,64,1,'1',1),(367,4,7,8,10,'10',0),(387,6,7,9,10,'10',0),(451,8,1,115,3,'3',1),(461,9,1,143,2,'2',1),(482,11,2,119,6,'6',0),(471,10,1,157,2,'2',1);
/*!40000 ALTER TABLE `constructorStandings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `constructors`
--

DROP TABLE IF EXISTS `constructors`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `constructors` (
  `constructorId` int(11) NOT NULL AUTO_INCREMENT,
  `constructorRef` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(255) NOT NULL DEFAULT '',
  `nationality` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`constructorId`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `constructors`
--

LOCK TABLES `constructors` WRITE;
/*!40000 ALTER TABLE `constructors` DISABLE KEYS */;
INSERT INTO `constructors` VALUES (1,'abt','Audi Sport ABT','German','http://en.wikipedia.org/wiki/Abt_Sportsline'),(2,'andretti','Andretti Autosport','American','http://en.wikipedia.org/wiki/Andretti_Autosport'),(3,'virgin','Virgin Racing','British','http://en.wikipedia.org/wiki/Virgin_Racing_(Formula_E_team)'),(4,'mahindra','Mahindra Racing','Indian','http://en.wikipedia.org/wiki/Mahindra_Racing'),(5,'dragon','Dragon Racing','American','http://en.wikipedia.org/wiki/Dragon_Racing'),(6,'china','NEXTEV TCR','Chinese','http://en.wikipedia.org/wiki/China_Racing'),(7,'venturi','Venturi Grand Prix','Monagasque','http://en.wikipedia.org/wiki/Venturi_Grand_Prix'),(8,'dams','e.dams-Renault','French','http://en.wikipedia.org/wiki/DAMS'),(9,'trulli','Trulli GP','Swiss','http://en.wikipedia.org/wiki/Trulli_GP'),(10,'aguri','Amlin Aguri','Japanese','http://en.wikipedia.org/wiki/Amlin_Aguri');
/*!40000 ALTER TABLE `constructors` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `driverStandings`
--

DROP TABLE IF EXISTS `driverStandings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `driverStandings` (
  `driverStandingsId` int(11) NOT NULL AUTO_INCREMENT,
  `raceId` int(11) NOT NULL DEFAULT '0',
  `driverId` int(11) NOT NULL DEFAULT '0',
  `points` float NOT NULL DEFAULT '0',
  `position` int(11) DEFAULT NULL,
  `positionText` varchar(255) DEFAULT NULL,
  `wins` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`driverStandingsId`)
) ENGINE=MyISAM AUTO_INCREMENT=826 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `driverStandings`
--

LOCK TABLES `driverStandings` WRITE;
/*!40000 ALTER TABLE `driverStandings` DISABLE KEYS */;
INSERT INTO `driverStandings` VALUES (378,1,20,0,20,'20',0),(370,1,12,3,9,'9',0),(371,1,13,0,14,'14',0),(372,1,14,0,15,'15',0),(373,1,15,0,16,'16',0),(374,1,16,0,17,'17',0),(367,1,9,2,10,'10',0),(366,1,8,4,8,'8',0),(359,1,1,25,1,'1',1),(477,5,26,0,26,'26',0),(376,1,18,0,18,'18',0),(377,1,19,0,19,'19',0),(375,1,17,2,11,'11',0),(369,1,11,0,13,'13',0),(368,1,10,1,12,'12',0),(365,1,7,6,7,'7',0),(364,1,6,8,6,'6',0),(363,1,5,10,5,'5',0),(362,1,4,12,4,'4',0),(361,1,3,15,3,'3',0),(360,1,2,18,2,'2',0),(475,5,23,14,15,'15',0),(478,5,27,18,11,'11',0),(471,5,20,18,13,'13',0),(466,5,15,0,28,'28',0),(480,5,28,0,29,'29',0),(479,5,29,6,18,'18',0),(455,5,4,12,17,'17',0),(456,5,5,18,12,'12',0),(476,5,25,1,22,'22',0),(474,5,24,0,24,'24',0),(459,5,8,49,4,'4',0),(473,5,22,0,27,'27',0),(472,5,21,37,6,'6',1),(468,5,17,2,21,'21',0),(469,5,18,43,5,'5',1),(470,5,19,12,16,'16',0),(467,5,16,0,23,'23',0),(465,5,14,0,25,'25',0),(464,5,13,5,19,'19',0),(463,5,12,67,1,'1',1),(462,5,11,26,8,'8',0),(461,5,10,19,9,'9',0),(460,5,9,3,20,'20',0),(458,5,7,16,14,'14',0),(457,5,6,34,7,'7',0),(454,5,3,52,3,'3',1),(453,5,2,18,10,'10',0),(452,5,1,60,2,'2',1),(398,2,20,0,20,'20',0),(396,2,18,15,7,'7',0),(394,2,16,0,16,'16',0),(393,2,15,0,21,'21',0),(391,2,13,0,18,'18',0),(389,2,11,4,12,'12',0),(388,2,10,2,14,'14',0),(386,2,8,4,10,'10',0),(385,2,7,12,9,'9',0),(384,2,6,18,6,'6',0),(382,2,4,12,8,'8',0),(380,2,2,18,3,'3',0),(392,2,14,0,19,'19',0),(400,2,22,0,17,'17',0),(399,2,21,4,11,'11',0),(397,2,19,0,22,'22',0),(381,2,3,40,2,'2',1),(395,2,17,2,15,'15',0),(387,2,9,2,13,'13',0),(379,2,1,43,1,'1',1),(390,2,12,18,4,'4',0),(383,2,5,18,5,'5',0),(425,3,25,0,25,'25',0),(424,3,23,3,16,'16',0),(423,3,24,0,21,'21',0),(421,3,21,4,14,'14',0),(418,3,18,40,2,'2',1),(417,3,17,2,18,'18',0),(416,3,16,0,20,'20',0),(414,3,14,0,22,'22',0),(412,3,12,24,4,'4',0),(410,3,10,4,15,'15',0),(407,3,7,14,10,'10',0),(406,3,6,22,6,'6',0),(405,3,5,18,8,'8',0),(403,3,3,40,3,'3',1),(411,3,11,14,9,'9',0),(419,3,19,12,11,'11',0),(420,3,20,8,13,'13',0),(422,3,22,0,23,'23',0),(409,3,9,2,17,'17',0),(408,3,8,22,5,'5',0),(402,3,2,18,7,'7',0),(413,3,13,1,19,'19',0),(415,3,15,0,24,'24',0),(404,3,4,12,12,'12',0),(401,3,1,58,1,'1',1),(451,4,26,0,23,'23',0),(450,4,25,0,26,'26',0),(449,4,23,11,15,'15',0),(448,4,24,0,21,'21',0),(447,4,22,0,24,'24',0),(446,4,21,29,6,'6',1),(445,4,20,18,11,'11',0),(444,4,19,12,13,'13',0),(443,4,18,43,3,'3',1),(441,4,16,0,20,'20',0),(439,4,14,0,22,'22',0),(437,4,12,42,4,'4',0),(434,4,9,3,18,'18',0),(433,4,8,37,5,'5',0),(427,4,2,18,9,'9',0),(442,4,17,2,19,'19',0),(435,4,10,4,17,'17',0),(436,4,11,26,7,'7',0),(438,4,13,5,16,'16',0),(440,4,15,0,25,'25',0),(429,4,4,12,14,'14',0),(430,4,5,18,10,'10',0),(431,4,6,22,8,'8',0),(432,4,7,16,12,'12',0),(426,4,1,58,1,'1',1),(428,4,3,48,2,'2',1),(509,6,28,0,27,'27',0),(508,6,29,8,18,'18',0),(507,6,27,18,13,'13',0),(505,6,25,1,22,'22',0),(504,6,23,32,8,'8',0),(503,6,24,0,24,'24',0),(501,6,21,43,6,'6',1),(499,6,19,12,16,'16',0),(497,6,17,2,21,'21',0),(495,6,15,0,29,'29',0),(493,6,13,5,19,'19',0),(491,6,11,30,9,'9',0),(489,6,9,4,20,'20',0),(486,6,6,42,7,'7',0),(484,6,4,12,17,'17',0),(482,6,2,18,12,'12',0),(506,6,26,0,26,'26',0),(500,6,20,28,10,'10',0),(494,6,14,0,25,'25',0),(490,6,10,22,11,'11',0),(496,6,16,0,23,'23',0),(485,6,5,18,14,'14',0),(498,6,18,55,4,'4',1),(483,6,3,52,5,'5',1),(502,6,22,0,28,'28',0),(488,6,8,74,2,'2',1),(492,6,12,69,3,'3',1),(487,6,7,16,15,'15',0),(481,6,1,75,1,'1',1),(680,7,13,6,20,'20',0),(689,7,22,0,28,'28',0),(686,7,19,12,17,'17',0),(669,7,2,18,13,'13',0),(694,7,27,18,12,'12',0),(696,7,28,0,27,'27',0),(695,7,29,8,19,'19',0),(693,7,26,0,26,'26',0),(692,7,25,1,22,'22',0),(691,7,23,34,8,'8',0),(690,7,24,0,24,'24',0),(688,7,21,45,7,'7',1),(687,7,20,28,10,'10',0),(670,7,3,64,5,'5',1),(685,7,18,83,3,'3',2),(684,7,17,2,21,'21',0),(682,7,15,0,29,'29',0),(683,7,16,0,23,'23',0),(681,7,14,0,25,'25',0),(679,7,12,77,4,'4',1),(678,7,11,30,9,'9',0),(676,7,9,10,18,'18',0),(677,7,10,22,11,'11',0),(675,7,8,89,2,'2',1),(674,7,7,16,16,'16',0),(672,7,5,18,14,'14',0),(671,7,4,16,15,'15',0),(668,7,1,93,1,'1',1),(722,8,26,0,27,'27',0),(719,8,24,0,25,'25',0),(710,8,14,0,26,'26',0),(723,8,27,18,13,'13',0),(716,8,20,28,10,'10',0),(717,8,21,45,7,'7',1),(725,8,28,2,21,'21',0),(724,8,29,23,11,'11',0),(701,8,5,18,15,'15',0),(721,8,25,1,23,'23',0),(720,8,23,40,8,'8',0),(718,8,22,0,28,'28',0),(715,8,19,12,20,'20',0),(714,8,18,101,2,'2',2),(711,8,15,0,29,'29',0),(709,8,13,16,18,'18',0),(708,8,12,77,4,'4',1),(707,8,11,30,9,'9',0),(705,8,9,18,16,'16',0),(703,8,7,16,19,'19',0),(712,8,16,0,24,'24',0),(713,8,17,2,22,'22',0),(702,8,6,77,5,'5',1),(699,8,3,68,6,'6',1),(700,8,4,16,17,'17',0),(698,8,2,18,14,'14',0),(697,8,1,93,3,'3',1),(748,9,24,0,26,'26',0),(739,9,14,0,27,'27',0),(740,9,15,0,30,'30',0),(741,9,16,0,25,'25',0),(742,9,17,2,23,'23',0),(743,9,18,105,3,'3',2),(744,9,19,15,20,'20',0),(745,9,20,28,12,'12',0),(755,9,30,1,24,'24',0),(754,9,28,2,22,'22',0),(752,9,27,18,14,'14',0),(751,9,26,0,28,'28',0),(749,9,23,55,7,'7',0),(747,9,22,0,29,'29',0),(746,9,21,51,8,'8',1),(738,9,13,31,10,'10',0),(737,9,12,81,4,'4',1),(736,9,11,30,11,'11',0),(735,9,10,32,9,'9',0),(734,9,9,18,17,'17',0),(733,9,8,128,1,'1',2),(731,9,6,77,5,'5',1),(732,9,7,16,19,'19',0),(730,9,5,18,16,'16',0),(750,9,25,9,21,'21',0),(729,9,4,16,18,'18',0),(728,9,3,68,6,'6',1),(727,9,2,18,15,'15',0),(726,9,1,111,2,'2',1),(789,10,32,0,34,'34',0),(778,10,24,0,27,'27',0),(784,10,28,2,22,'22',0),(780,10,25,9,21,'21',0),(781,10,26,0,30,'30',0),(790,10,34,0,35,'35',0),(788,10,31,0,32,'32',0),(787,10,33,0,28,'28',0),(786,10,35,2,23,'23',0),(785,10,30,1,25,'25',0),(783,10,29,27,13,'13',0),(777,10,22,0,31,'31',0),(782,10,27,18,15,'15',0),(779,10,23,70,7,'7',0),(776,10,21,51,8,'8',1),(756,10,1,125,3,'3',1),(757,10,2,18,16,'16',0),(758,10,3,76,6,'6',1),(759,10,4,16,18,'18',0),(760,10,5,18,17,'17',0),(761,10,6,95,4,'4',1),(762,10,7,16,19,'19',0),(763,10,8,138,1,'1',2),(764,10,9,19,14,'14',0),(765,10,10,32,9,'9',0),(766,10,11,30,11,'11',0),(767,10,12,87,5,'5',1),(768,10,13,31,10,'10',0),(769,10,14,0,29,'29',0),(770,10,15,0,33,'33',0),(771,10,16,0,26,'26',0),(772,10,17,2,24,'24',0),(773,10,18,133,2,'2',3),(774,10,19,15,20,'20',0),(775,10,20,28,12,'12',0),(820,11,30,1,25,'25',0),(818,11,29,42,9,'9',0),(814,11,23,70,7,'7',0),(816,11,26,0,30,'30',0),(825,11,34,0,35,'35',0),(824,11,32,0,33,'33',0),(823,11,31,0,32,'32',0),(822,11,33,0,28,'28',0),(821,11,35,4,22,'22',0),(819,11,28,2,23,'23',0),(817,11,27,18,16,'16',0),(815,11,25,13,21,'21',0),(813,11,24,0,27,'27',0),(812,11,22,0,31,'31',0),(791,11,1,133,3,'3',1),(792,11,2,18,15,'15',0),(793,11,3,103,5,'5',2),(794,11,4,16,18,'18',0),(795,11,5,18,17,'17',0),(796,11,6,113,4,'4',1),(797,11,7,16,19,'19',0),(798,11,8,144,1,'1',2),(799,11,9,22,14,'14',0),(800,11,10,32,11,'11',0),(801,11,11,30,13,'13',0),(802,11,12,88,6,'6',1),(803,11,13,31,12,'12',0),(804,11,14,0,29,'29',0),(805,11,15,0,34,'34',0),(806,11,16,0,26,'26',0),(807,11,17,2,24,'24',0),(808,11,18,143,2,'2',3),(809,11,19,15,20,'20',0),(810,11,20,40,10,'10',0),(673,7,6,52,6,'6',0),(704,8,8,103,1,'1',1),(706,8,10,22,12,'12',0),(753,9,29,23,13,'13',0),(811,11,21,51,8,'8',1);
/*!40000 ALTER TABLE `driverStandings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `drivers`
--

DROP TABLE IF EXISTS `drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `drivers` (
  `driverId` int(11) NOT NULL AUTO_INCREMENT,
  `driverRef` varchar(255) NOT NULL DEFAULT '',
  `number` int(11) DEFAULT NULL,
  `code` varchar(3) DEFAULT NULL,
  `forename` varchar(255) NOT NULL DEFAULT '',
  `surname` varchar(255) NOT NULL DEFAULT '',
  `dob` date DEFAULT NULL,
  `nationality` varchar(255) DEFAULT NULL,
  `url` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`driverId`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drivers`
--

LOCK TABLES `drivers` WRITE;
/*!40000 ALTER TABLE `drivers` DISABLE KEYS */;
INSERT INTO `drivers` VALUES (1,'grassi',11,'DIG','Lucas','di Grassi','1984-08-11','Brazilian','http://en.wikipedia.org/wiki/Lucas_di_Grassi'),(2,'montagny',27,'MON','Franck','Montagny','1978-01-05','French','http://en.wikipedia.org/wiki/Franck_Montagny'),(3,'bird',2,'BIR','Sam','Bird','1987-01-09','British','http://en.wikipedia.org/wiki/Sam_Bird'),(4,'pic',28,'PIC','Charles','Pic','1990-02-15','French','http://en.wikipedia.org/wiki/Charles_Pic'),(5,'chandhok',5,'CHA','Karun','Chandhok','1984-01-19','Indian','http://en.wikipedia.org/wiki/Karun_Chandhok'),(6,'ambrosio',7,'DAM','Jérôme','d\'Ambrosio','1985-12-27','Belgian','http://en.wikipedia.org/wiki/Jerome_d%27Ambrosio'),(7,'servia',6,'SER','Oriol','Servià','1974-07-13','Spanish','http://en.wikipedia.org/wiki/Oriol_Servi%C3%A0'),(8,'piquet_jr',99,'PIQ','Nelson','Piquet Jr.','1985-07-25','Brazilian','http://en.wikipedia.org/wiki/Nelson_Piquet,_Jr.'),(9,'sarrazin',30,'SAR','Stéphane','Sarrazin','1975-11-02','French','http://en.wikipedia.org/wiki/St%C3%A9phane_Sarrazin'),(10,'abt',66,'ABT','Daniel','Abt','1992-12-03','German','http://en.wikipedia.org/wiki/Daniel_Abt'),(11,'alguersuari',3,'ALG','Jaime','Alguersuari','1990-03-23','Spanish','http://en.wikipedia.org/wiki/Jaime_Alguersuari'),(12,'nicolas_prost',8,'PRO','Nicolas','Prost','1981-08-18','French','http://en.wikipedia.org/wiki/Nicolas_Prost'),(13,'heidfeld',23,'HEI','Nick','Heidfeld','1977-05-10','German','http://en.wikipedia.org/wiki/Nick_Heidfeld'),(14,'cerruti',18,'CER','Michela','Cerruti','1987-02-18','Italian','http://en.wikipedia.org/wiki/Michela_Cerruti'),(15,'legge',77,'LEG','Katherine','Legge','1980-07-12','British','http://en.wikipedia.org/wiki/Katherine_Legge'),(16,'tung',88,'TUN','Ho-Pin','Tung','1982-12-04','Chinese','http://en.wikipedia.org/wiki/Ho-Pin_Tung'),(17,'sato',55,'SAT','Takuma','Sato','1977-01-28','Japanese','http://en.wikipedia.org/wiki/Takuma_Sato'),(18,'buemi',9,'BUE','Sébastien','Buemi','1988-10-31','Swiss','http://en.wikipedia.org/wiki/Sebastien_Buemi'),(19,'trulli',10,'TRU','Jarno','Trulli','1974-07-13','Italian','http://en.wikipedia.org/wiki/Jarno_Trulli'),(20,'senna',21,'SEN','Bruno','Senna','1983-10-15','Brazilian','http://en.wikipedia.org/wiki/Bruno_Senna'),(21,'costa',NULL,'DAC','António','Félix da Costa','1991-08-31','Portuguese','http://en.wikipedia.org/wiki/Ant%C3%B3nio_F%C3%A9lix_da_Costa'),(22,'brabham',NULL,'BRA','Matthew','Brabham','1994-02-25','American','http://en.wikipedia.org/wiki/Matthew_Brabham'),(23,'vergne',NULL,'VER','Jean-Éric','Vergne','1990-04-25','French','http://en.wikipedia.org/wiki/Jean-%C3%89ric_Vergne'),(24,'garcia',NULL,'GAR','Antonio','García','1980-06-05','Spanish','http://en.wikipedia.org/wiki/Antonio_Garc%C3%ADa_%28racing_driver%29'),(25,'duran',NULL,'dur','Salvador','Durán','1985-05-06','Mexican','http://en.wikipedia.org/wiki/Salvador_Dur%C3%A1n'),(26,'andretti',NULL,'AND','Marco','Andretti','1987-03-13','American','http://en.wikipedia.org/wiki/Marco_Andretti'),(27,'speed',NULL,'SPE','Scott','Speed','1983-01-24','American','https://en.wikipedia.org/wiki/Scott_Speed'),(28,'liuzzi',NULL,'LIU','Vitantonio','Liuzzi','1980-08-06','Italian','https://en.wikipedia.org/wiki/Vitantonio_Liuzzi'),(29,'duval',NULL,'DUV','Loïc','Duval','1982-06-12','French','https://en.wikipedia.org/wiki/Lo%C3%AFc_Duval'),(30,'wilson',NULL,'WIL','Justin','Wilson','1978-07-31','British','http://en.wikipedia.org/wiki/Justin_Wilson_%28racing_driver%29'),(31,'leimer',NULL,'LEI','Fabio','Leimer','1989-04-17','Swiss','http://en.wikipedia.org/wiki/Fabio_Leimer'),(32,'fontana',NULL,'FON','Alex','Fontana','1992-08-05','Swiss','http://en.wikipedia.org/wiki/Alex_Fontana'),(33,'silvestro',NULL,'DES','Simona','de Silvestro','1988-09-01','Swiss','http://en.wikipedia.org/wiki/Simona_de_Silvestro'),(34,'yamamoto',NULL,'YAM','Sakon','Yamamoto','1982-07-09','Japanese','https://en.wikipedia.org/wiki/Sakon_Yamamoto'),(35,'turvey',NULL,'TUR','Oliver','Turvey','1987-04-01','British','https://en.wikipedia.org/wiki/Oliver_Turvey');
/*!40000 ALTER TABLE `drivers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lapTimes`
--

DROP TABLE IF EXISTS `lapTimes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `lapTimes` (
  `raceId` int(11) NOT NULL,
  `driverId` int(11) NOT NULL,
  `lap` int(11) NOT NULL,
  `position` int(11) DEFAULT NULL,
  `time` varchar(255) DEFAULT NULL,
  `milliseconds` int(11) DEFAULT NULL,
  PRIMARY KEY (`raceId`,`driverId`,`lap`),
  KEY `raceId` (`raceId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lapTimes`
--

LOCK TABLES `lapTimes` WRITE;
/*!40000 ALTER TABLE `lapTimes` DISABLE KEYS */;
/*!40000 ALTER TABLE `lapTimes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pitStops`
--

DROP TABLE IF EXISTS `pitStops`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pitStops` (
  `raceId` int(11) NOT NULL,
  `driverId` int(11) NOT NULL,
  `stop` int(11) NOT NULL,
  `lap` int(11) NOT NULL,
  `time` time NOT NULL,
  `duration` varchar(255) DEFAULT NULL,
  `milliseconds` int(11) DEFAULT NULL,
  PRIMARY KEY (`raceId`,`driverId`,`stop`),
  KEY `raceId` (`raceId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pitStops`
--

LOCK TABLES `pitStops` WRITE;
/*!40000 ALTER TABLE `pitStops` DISABLE KEYS */;
/*!40000 ALTER TABLE `pitStops` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `qualifying`
--

DROP TABLE IF EXISTS `qualifying`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `qualifying` (
  `qualifyId` int(11) NOT NULL AUTO_INCREMENT,
  `raceId` int(11) NOT NULL DEFAULT '0',
  `driverId` int(11) NOT NULL DEFAULT '0',
  `constructorId` int(11) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL DEFAULT '0',
  `position` int(11) DEFAULT NULL,
  `q1` varchar(255) DEFAULT NULL,
  `q2` varchar(255) DEFAULT NULL,
  `q3` varchar(255) CHARACTER SET ucs2 DEFAULT NULL,
  PRIMARY KEY (`qualifyId`)
) ENGINE=MyISAM AUTO_INCREMENT=197 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `qualifying`
--

LOCK TABLES `qualifying` WRITE;
/*!40000 ALTER TABLE `qualifying` DISABLE KEYS */;
INSERT INTO `qualifying` VALUES (1,1,12,8,8,1,'1:42.200',NULL,NULL),(2,1,1,1,11,2,'1:42.306',NULL,NULL),(3,1,10,1,66,3,'1:42.454',NULL,NULL),(4,1,5,4,5,4,'1:42.461',NULL,NULL),(5,1,2,2,27,5,'1:42.530',NULL,NULL),(6,1,13,7,23,6,'1:42.579',NULL,NULL),(7,1,11,3,3,7,'1:42.683',NULL,NULL),(8,1,4,2,28,8,'1:42.726',NULL,NULL),(9,1,18,8,9,9,'1:42.746',NULL,NULL),(10,1,8,6,99,10,'1:42.785',NULL,NULL),(11,1,7,5,6,11,'1:42.847',NULL,NULL),(12,1,3,3,2,12,'1:42.918',NULL,NULL),(13,1,6,5,7,13,'1:44.056',NULL,NULL),(14,1,17,10,55,14,'1:44.129',NULL,NULL),(15,1,16,6,88,15,'1:45.282',NULL,NULL),(16,1,15,10,77,16,'1:45.369',NULL,NULL),(17,1,14,9,18,17,'1:46.170',NULL,NULL),(18,1,19,9,10,18,'2:16.788',NULL,NULL),(19,1,20,4,21,19,'2:32.729',NULL,NULL),(20,1,9,7,30,20,'3:22.723',NULL,NULL),(21,2,12,8,8,1,'1:21.779',NULL,NULL),(22,2,7,5,6,2,'1:22.010',NULL,NULL),(23,2,3,3,2,3,'1:22.235',NULL,NULL),(24,2,10,1,66,4,'1:22.342',NULL,NULL),(25,2,19,9,10,5,'1:22.347',NULL,NULL),(26,2,5,4,5,6,'1:22.612',NULL,NULL),(27,2,8,6,99,7,'1:22.620',NULL,NULL),(28,2,13,7,23,8,'1:22.720',NULL,NULL),(29,2,20,4,21,9,'1:22.816',NULL,NULL),(30,2,22,2,28,10,'1:22.941',NULL,NULL),(31,2,21,10,55,11,'1:23.194',NULL,NULL),(32,2,9,7,30,12,'1:23.240',NULL,NULL),(33,2,2,2,27,13,'1:23.697',NULL,NULL),(34,2,14,9,18,14,'1:23.857',NULL,NULL),(35,2,16,6,88,15,'1:23.894',NULL,NULL),(36,2,15,10,77,16,'1:25.823',NULL,NULL),(37,2,11,3,3,17,'',NULL,NULL),(38,2,1,1,11,18,'',NULL,NULL),(39,2,18,8,9,19,'',NULL,NULL),(40,2,6,5,7,20,'',NULL,NULL),(41,3,23,2,27,1,'1:15.408',NULL,NULL),(42,3,8,6,99,2,'1:15.530',NULL,NULL),(43,3,12,8,8,3,'1:15.722',NULL,NULL),(44,3,18,8,9,4,'1:15.842',NULL,NULL),(45,3,11,3,3,5,'1:16.053',NULL,NULL),(46,3,1,1,11,6,'1:16.108',NULL,NULL),(47,3,19,9,10,7,'1:16.144',NULL,NULL),(48,3,20,4,21,8,'1:16.211',NULL,NULL),(49,3,13,7,23,9,'1:16.225',NULL,NULL),(50,3,10,1,66,10,'1:16.374',NULL,NULL),(51,3,5,4,5,11,'1:16.416',NULL,NULL),(52,3,7,5,6,12,'1:16.811',NULL,NULL),(53,3,21,10,55,13,'1:16.865',NULL,NULL),(54,3,9,7,30,14,'1:17.025',NULL,NULL),(55,3,24,6,88,15,'1:17.653',NULL,NULL),(56,3,25,10,77,16,'1:17.810',NULL,NULL),(57,3,14,9,18,17,'1:20.206',NULL,NULL),(58,4,18,8,9,1,'1:09.134',NULL,NULL),(59,4,11,3,3,2,'1:09.161',NULL,NULL),(60,4,13,7,23,3,'1:09.367',NULL,NULL),(61,4,3,3,2,4,'1:09.388',NULL,NULL),(62,4,1,1,11,5,'1:09.521',NULL,NULL),(63,4,23,2,27,6,'1:09.527',NULL,NULL),(64,4,12,8,8,7,'1:09.636',NULL,NULL),(65,4,21,10,55,8,'1:09.658',NULL,NULL),(66,4,8,6,99,9,'1:09.742',NULL,NULL),(67,4,5,4,5,10,'1:09.875',NULL,NULL),(68,4,9,7,30,11,'1:10.165',NULL,NULL),(69,4,10,1,66,12,'1:10.329',NULL,NULL),(70,4,7,5,6,13,'1:10.588',NULL,NULL),(71,4,26,2,28,14,'1:10.713',NULL,NULL),(72,4,16,6,88,15,'1:11.049',NULL,NULL),(73,4,25,10,23,16,'1:11.331',NULL,NULL),(74,4,14,9,18,17,'1:11.785',NULL,NULL),(75,4,6,5,7,18,'1:12.239',NULL,NULL),(76,4,20,4,21,19,'1:13.209',NULL,NULL),(77,4,19,9,10,20,NULL,NULL,NULL),(78,5,23,2,0,1,'1:05.953',NULL,NULL),(79,5,8,6,0,2,'1:06.003',NULL,NULL),(80,5,12,8,0,3,'1:06.167',NULL,NULL),(81,5,3,3,0,4,'1:06.170',NULL,NULL),(82,5,10,1,0,5,'1:06.255',NULL,NULL),(83,5,9,7,0,6,'1:06.389',NULL,NULL),(84,5,1,1,0,7,'1:06.424',NULL,NULL),(85,5,6,5,0,8,'1:06.502',NULL,NULL),(86,5,11,3,0,9,'1:06.503',NULL,NULL),(87,5,27,2,0,10,'1:06.527',NULL,NULL),(88,5,28,9,0,11,'1:06.836',NULL,NULL),(89,5,25,10,0,12,'1:06.888',NULL,NULL),(90,5,18,8,0,13,'1:07.037',NULL,NULL),(91,5,19,9,0,14,'1:07.163',NULL,NULL),(92,5,20,4,0,15,'1:07.283',NULL,NULL),(93,5,21,10,0,16,'1:07.678',NULL,NULL),(94,5,4,6,0,17,'1:08.243',NULL,NULL),(95,5,29,5,0,18,'1:09.454',NULL,NULL),(96,5,13,7,0,19,'1:06.510',NULL,NULL),(97,5,5,4,0,20,'1:07.223',NULL,NULL),(98,7,18,8,9,1,'53.478',NULL,NULL),(99,7,1,1,11,2,'53.669',NULL,NULL),(100,7,6,5,7,3,'53.702',NULL,NULL),(101,7,8,6,99,4,'53.712',NULL,NULL),(102,7,29,5,6,5,'53.804',NULL,NULL),(103,7,10,1,66,6,'53.891',NULL,NULL),(104,7,12,8,8,7,'53.909',NULL,NULL),(105,7,11,3,3,8,'54.021',NULL,NULL),(106,7,20,4,21,9,'54.035',NULL,NULL),(107,7,9,7,30,10,'54.133',NULL,NULL),(108,7,25,10,77,11,'54.175',NULL,NULL),(109,7,3,3,2,12,'54.253',NULL,NULL),(110,7,23,2,27,13,'54.260',NULL,NULL),(111,7,19,9,10,14,'54.339',NULL,NULL),(112,7,27,2,28,15,'54.347',NULL,NULL),(113,7,28,9,18,16,'54.462',NULL,NULL),(114,7,13,7,23,17,'54.502',NULL,NULL),(115,7,4,6,88,18,'54.652',NULL,NULL),(116,7,5,4,5,19,'54.858',NULL,NULL),(117,7,21,10,55,20,'56.938',NULL,NULL),(118,8,19,9,10,1,'1:21.547',NULL,NULL),(119,8,1,1,11,2,'1:21.623',NULL,NULL),(120,8,18,8,9,3,'1:21.685',NULL,NULL),(121,8,13,7,23,4,'1:21.710',NULL,NULL),(122,8,10,1,66,5,'1:21.754',NULL,NULL),(123,8,6,5,7,6,'1:21.861',NULL,NULL),(124,8,12,8,8,7,'1:21.911',NULL,NULL),(125,8,29,5,6,8,'1:21.917',NULL,NULL),(126,8,9,7,30,9,'1:21.978',NULL,NULL),(127,8,23,2,27,10,'1:22.015',NULL,NULL),(128,8,28,9,18,11,'1:22.032',NULL,NULL),(129,8,27,2,28,12,'1:22.096',NULL,NULL),(130,8,8,6,99,13,'1:22.310',NULL,NULL),(131,8,11,3,3,14,'1:22.395',NULL,NULL),(132,8,3,3,2,15,'1:22.437',NULL,NULL),(133,8,25,10,77,16,'1:22.444',NULL,NULL),(134,8,4,6,88,17,'1:22.464',NULL,NULL),(135,8,20,4,21,18,'1:22.575',NULL,NULL),(136,8,21,10,55,19,'1:22.586',NULL,NULL),(137,8,5,4,5,20,'1:22.803',NULL,NULL),(138,9,23,2,27,1,'1:09.429',NULL,NULL),(139,9,8,6,99,2,'1:09.449',NULL,NULL),(140,9,1,1,11,3,'1:09.685',NULL,NULL),(141,9,18,8,9,4,'1:09.826',NULL,NULL),(142,9,6,5,7,5,'1:09.967',NULL,NULL),(143,9,12,8,8,6,'1:10.043',NULL,NULL),(144,9,10,1,66,7,'1:10.075',NULL,NULL),(145,9,13,7,23,8,'1:10.098',NULL,NULL),(146,9,19,9,10,9,'1:10.145',NULL,NULL),(147,9,25,10,77,10,'1:10.257',NULL,NULL),(148,9,3,3,2,11,'1:10.365',NULL,NULL),(149,9,30,2,28,12,'1:10.398',NULL,NULL),(150,9,24,6,88,13,'1:10.537',NULL,NULL),(151,9,21,10,55,14,'1:10.617',NULL,NULL),(152,9,20,4,21,15,'1:10.688',NULL,NULL),(153,9,5,4,5,16,'1:10.697',NULL,NULL),(154,9,11,3,3,17,'1:10.941',NULL,NULL),(155,9,29,5,6,18,'1:11.141',NULL,NULL),(156,9,28,9,18,19,'1:11.967',NULL,NULL),(157,10,18,8,9,1,'1:24.648',NULL,NULL),(158,10,6,5,7,2,'1:25.104',NULL,NULL),(159,10,1,1,11,3,'1:25.105',NULL,NULL),(160,10,8,6,99,4,'1:25.144',NULL,NULL),(161,10,23,2,27,5,'1:25.182',NULL,NULL),(162,10,12,8,8,6,'1:25.258',NULL,NULL),(163,10,35,6,88,7,'1:25.829',NULL,NULL),(164,10,20,4,21,8,'1:25.879',NULL,NULL),(165,10,3,3,2,9,'1:25.894',NULL,NULL),(166,10,25,10,77,10,'1:25.964',NULL,NULL),(167,10,29,5,6,11,'1:25.998',NULL,NULL),(168,10,13,7,23,12,'1:26.128',NULL,NULL),(169,10,10,1,66,13,'1:26.302',NULL,NULL),(170,10,9,7,30,14,'1:26.318',NULL,NULL),(171,10,19,9,10,15,'1:26.852',NULL,NULL),(172,10,5,4,5,16,'1:27.160',NULL,NULL),(173,10,33,2,28,17,'1:27.208',NULL,NULL),(174,10,34,10,55,18,'1:27.456',NULL,NULL),(175,10,32,9,18,19,'1:28.083',NULL,NULL),(176,10,31,3,3,20,'1:28.152',NULL,NULL),(177,11,9,7,30,1,'1:23.901',NULL,NULL),(178,11,6,5,7,2,'1:23.965',NULL,NULL),(179,11,29,5,6,3,'1:24.107',NULL,NULL),(180,11,3,3,2,4,'1:24.241',NULL,NULL),(181,11,20,4,21,5,'1:24.318',NULL,NULL),(182,11,18,8,9,6,'1:24.385',NULL,NULL),(183,11,13,7,23,7,'1:25.494',NULL,NULL),(184,11,25,10,77,8,'1:25.649',NULL,NULL),(185,11,32,9,18,9,'1:25.689',NULL,NULL),(186,11,19,9,10,10,'1:27.093',NULL,NULL),(187,11,1,1,11,11,'1:32.570',NULL,NULL),(188,11,35,6,88,12,'1:33.626',NULL,NULL),(189,11,33,2,28,13,'1:34.167',NULL,NULL),(190,11,23,2,27,14,'1:35.032',NULL,NULL),(191,11,12,8,8,15,'1:35.111',NULL,NULL),(192,11,8,6,99,16,'1:35.284',NULL,NULL),(193,11,31,3,3,17,'1:35.543',NULL,NULL),(194,11,10,1,66,18,'1:38.473',NULL,NULL),(195,11,5,4,5,19,'1:41.232',NULL,NULL),(196,11,34,10,55,20,NULL,NULL,NULL);
/*!40000 ALTER TABLE `qualifying` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `races`
--

DROP TABLE IF EXISTS `races`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `races` (
  `raceId` int(11) NOT NULL AUTO_INCREMENT,
  `year` int(11) NOT NULL DEFAULT '0',
  `round` int(11) NOT NULL DEFAULT '0',
  `circuitId` int(11) NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL DEFAULT '',
  `date` date NOT NULL DEFAULT '0000-00-00',
  `time` time DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`raceId`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `races`
--

LOCK TABLES `races` WRITE;
/*!40000 ALTER TABLE `races` DISABLE KEYS */;
INSERT INTO `races` VALUES (1,2014,1,1,'Beijing ePrix','2014-09-13',NULL,'http://en.wikipedia.org/wiki/2014_Beijing_ePrix'),(2,2014,2,2,'Putrajaya ePrix','2014-11-22',NULL,'http://en.wikipedia.org/wiki/2014_Putrajaya_ePrix'),(3,2014,3,3,'Punta del Este ePrix','2014-12-13',NULL,'http://en.wikipedia.org/wiki/2014_Punta_del_Este_ePrix'),(4,2014,4,4,'Buenos Aires ePrix','2015-01-10',NULL,'http://en.wikipedia.org/wiki/2015_Buenos_Aires_ePrix'),(5,2014,5,5,'Miami ePrix','2015-03-14',NULL,'http://en.wikipedia.org/wiki/2015_Miami_ePrix'),(6,2014,6,6,'Long Beach ePrix','2015-04-04',NULL,'http://en.wikipedia.org/wiki/2015_Long_Beach_ePrix'),(7,2014,7,8,'Monte Carlo ePrix','2015-05-09',NULL,'http://en.wikipedia.org/wiki/2015_Monte_Carlo_ePrix'),(8,2014,8,7,'Berlin ePrix','2015-05-23',NULL,'http://en.wikipedia.org/wiki/2015_Berlin_ePrix'),(9,2014,9,11,'Moscow ePrix','2015-06-06',NULL,'http://en.wikipedia.org/wiki/2015_Moscow_ePrix'),(10,2014,10,9,'London ePrix Race 1','2015-06-27',NULL,'http://en.wikipedia.org/wiki/2015_London_ePrix#Race_One'),(11,2014,11,9,'London ePrix Race 2','2015-06-28',NULL,'http://en.wikipedia.org/wiki/2015_London_ePrix#Race_Two');
/*!40000 ALTER TABLE `races` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `results`
--

DROP TABLE IF EXISTS `results`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `results` (
  `resultId` int(11) NOT NULL AUTO_INCREMENT,
  `raceId` int(11) NOT NULL DEFAULT '0',
  `driverId` int(11) NOT NULL DEFAULT '0',
  `constructorId` int(11) NOT NULL DEFAULT '0',
  `number` int(11) NOT NULL DEFAULT '0',
  `grid` int(11) NOT NULL DEFAULT '0',
  `position` int(11) DEFAULT NULL,
  `positionText` varchar(255) NOT NULL DEFAULT '',
  `positionOrder` int(11) NOT NULL DEFAULT '0',
  `points` float NOT NULL DEFAULT '0',
  `laps` int(11) NOT NULL DEFAULT '0',
  `time` varchar(255) DEFAULT NULL,
  `milliseconds` int(11) DEFAULT NULL,
  `fastestLap` int(11) DEFAULT NULL,
  `rank` int(11) DEFAULT '0',
  `fastestLapTime` varchar(255) DEFAULT NULL,
  `fastestLapSpeed` varchar(255) DEFAULT NULL,
  `statusId` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`resultId`)
) ENGINE=MyISAM AUTO_INCREMENT=221 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `results`
--

LOCK TABLES `results` WRITE;
/*!40000 ALTER TABLE `results` DISABLE KEYS */;
INSERT INTO `results` VALUES (1,1,1,1,11,2,1,'1',1,25,25,'52:23.413',3143413,NULL,0,NULL,NULL,1),(2,1,2,2,27,8,2,'2',2,18,25,'+2.867',3146280,NULL,0,NULL,NULL,1),(3,1,3,3,2,11,3,'3',3,15,25,'+6.559',3149972,NULL,0,NULL,NULL,1),(4,1,4,2,28,7,4,'4',4,12,25,'+19.301',3162714,NULL,0,NULL,NULL,1),(5,1,5,4,5,4,5,'5',5,10,25,'+23.952',3167365,NULL,0,NULL,NULL,1),(6,1,6,5,7,12,6,'6',6,8,25,'+31.664',3175077,NULL,0,NULL,NULL,1),(7,1,7,5,6,10,7,'7',7,6,25,'+41.968',3185381,NULL,0,NULL,NULL,1),(8,1,8,6,99,9,8,'8',8,4,25,'+43.896',3187309,NULL,0,NULL,NULL,1),(9,1,9,7,30,19,9,'9',9,2,25,'+43.975',3187388,NULL,0,NULL,NULL,1),(10,1,10,1,66,3,10,'10',10,1,25,'+1:02.507',3205920,NULL,0,NULL,NULL,1),(11,1,11,3,3,6,11,'11',11,0,25,'+2:00.613',3264026,NULL,0,NULL,NULL,1),(12,1,12,8,8,1,12,'12',12,3,24,NULL,NULL,NULL,0,NULL,NULL,12),(13,1,13,7,23,5,13,'13',13,0,24,NULL,NULL,NULL,0,NULL,NULL,12),(14,1,14,9,18,16,14,'14',14,0,24,NULL,NULL,NULL,0,NULL,NULL,2),(15,1,15,10,77,14,15,'15',15,0,24,NULL,NULL,NULL,0,NULL,NULL,2),(16,1,16,6,88,17,16,'16',16,0,24,NULL,NULL,NULL,0,NULL,NULL,2),(17,1,17,10,55,13,NULL,'R',17,2,21,NULL,NULL,NULL,0,NULL,NULL,5),(18,1,18,8,9,18,NULL,'R',18,0,14,NULL,NULL,NULL,0,NULL,NULL,11),(19,1,19,9,10,20,NULL,'R',19,0,0,NULL,NULL,NULL,0,NULL,NULL,11),(20,1,20,4,21,15,NULL,'R',20,0,0,NULL,NULL,NULL,0,NULL,NULL,12),(21,2,3,3,2,2,1,'1',1,25,31,'51:11.979',3071979,NULL,0,NULL,NULL,1),(22,2,1,1,11,18,2,'2',2,18,31,'+ 4.175',3076154,NULL,0,NULL,NULL,1),(23,2,18,8,9,19,3,'3',3,15,31,'+ 5.739',3077718,NULL,0,NULL,NULL,1),(24,2,12,8,8,11,4,'4',4,15,31,'+ 9.552',3081531,NULL,0,NULL,NULL,1),(25,2,6,5,7,20,5,'5',5,10,31,'+ 13.722',3085701,NULL,0,NULL,NULL,1),(26,2,5,4,5,5,6,'6',6,8,31,'+ 17.158',3089137,NULL,0,NULL,NULL,1),(27,2,7,5,6,1,7,'7',7,6,31,'+ 18.621',3090600,NULL,0,NULL,NULL,1),(28,2,21,10,55,10,8,'8',8,4,31,'+19.926',3091905,NULL,0,NULL,NULL,1),(29,2,11,3,3,17,9,'9',9,4,31,'+20.053',3092032,NULL,0,NULL,NULL,1),(30,2,10,1,66,3,10,'10',10,1,31,'+45.663',3117642,NULL,0,NULL,NULL,1),(31,2,16,6,88,15,11,'11',11,0,31,'+55.833',3127812,NULL,0,NULL,NULL,1),(32,2,9,7,30,12,12,'12',12,0,31,'+56.626',3128605,NULL,0,NULL,NULL,1),(33,2,22,2,28,9,13,'13',13,0,31,'+1:05.036',3137015,NULL,0,NULL,NULL,1),(34,2,20,4,21,8,14,'14',14,0,30,NULL,NULL,NULL,0,NULL,NULL,13),(35,2,2,2,27,13,15,'15',15,0,30,NULL,NULL,NULL,0,NULL,NULL,2),(36,2,15,10,77,16,16,'16',16,0,28,NULL,NULL,NULL,0,NULL,NULL,4),(37,2,19,9,10,5,17,'17',17,0,28,NULL,NULL,NULL,0,NULL,NULL,4),(38,2,8,6,99,7,NULL,'R',18,0,22,NULL,NULL,NULL,0,NULL,NULL,12),(39,2,14,9,18,14,NULL,'R',19,0,7,NULL,NULL,NULL,0,NULL,NULL,12),(40,2,13,7,23,8,NULL,'E',20,0,14,NULL,NULL,NULL,0,NULL,NULL,0),(41,3,18,8,9,4,1,'1',1,25,31,'49:08.990',2948990,NULL,0,NULL,NULL,1),(42,3,8,6,99,2,2,'2',2,18,31,'+0.732',2949722,NULL,0,NULL,NULL,1),(43,3,1,1,11,6,3,'3',3,15,31,'+2.635',2951625,NULL,0,NULL,NULL,1),(44,3,19,9,10,7,4,'4',4,12,31,'+4.163',2953153,NULL,0,NULL,NULL,1),(45,3,11,3,3,5,5,'5',5,10,31,'+4.698',2953688,NULL,0,NULL,NULL,1),(46,3,20,4,21,20,6,'6',6,8,31,'+5.197',2954187,NULL,0,NULL,NULL,1),(47,3,12,8,8,3,7,'7',7,6,31,'+6.514',2955504,NULL,0,NULL,NULL,1),(48,3,6,5,7,17,8,'8',8,4,31,'+7.567',2956557,NULL,0,NULL,NULL,1),(49,3,7,5,6,11,9,'9',9,2,31,'+8.646',2957636,NULL,0,NULL,NULL,1),(50,3,13,7,23,8,10,'10',10,1,31,'+10.563',2959553,NULL,0,NULL,NULL,1),(51,3,24,6,88,14,11,'11',11,0,31,'+10.594',2959584,NULL,0,NULL,NULL,1),(52,3,14,9,18,16,12,'12',12,0,31,'+19.617',2968607,NULL,0,NULL,NULL,1),(53,3,5,4,5,10,13,'13',13,0,31,'+54.175',3003165,NULL,0,NULL,NULL,1),(54,3,23,2,27,1,14,'14',14,3,29,NULL,NULL,NULL,0,NULL,NULL,3),(55,3,10,1,66,9,15,'15',15,2,28,NULL,NULL,NULL,0,NULL,NULL,4),(56,3,25,10,77,15,16,'16',16,0,27,NULL,NULL,NULL,0,NULL,NULL,5),(57,3,22,2,28,19,NULL,'R',17,0,26,NULL,NULL,NULL,0,NULL,NULL,11),(58,3,9,7,30,13,NULL,'R',18,0,15,NULL,NULL,NULL,0,NULL,NULL,11),(59,3,21,10,55,12,NULL,'R',19,0,6,NULL,NULL,NULL,0,NULL,NULL,11),(60,3,3,3,2,18,NULL,'R',20,0,3,NULL,NULL,NULL,0,NULL,NULL,11),(61,4,21,10,55,8,1,'1',1,25,35,'48:52.100',2932100,NULL,0,NULL,NULL,1),(62,4,12,8,8,7,2,'2',2,18,35,'+5.354',2937454,NULL,0,NULL,NULL,1),(63,4,8,6,99,9,3,'3',3,15,35,'+8.552',2940652,NULL,0,NULL,NULL,1),(64,4,11,3,3,2,4,'4',4,12,35,'+11.148',2943248,NULL,0,NULL,NULL,1),(65,4,20,4,21,19,5,'5',5,10,35,'+11.535',2943635,NULL,0,NULL,NULL,1),(66,4,23,2,27,6,6,'6',6,8,35,'+13.319',2945419,NULL,0,NULL,NULL,1),(67,4,3,3,2,4,7,'7',7,8,35,'+13.617',2945717,NULL,0,NULL,NULL,1),(68,4,13,7,23,3,8,'8',8,4,35,'+15.464',2947564,NULL,0,NULL,NULL,1),(69,4,7,5,6,13,9,'9',9,2,35,'+19.334',2951434,NULL,0,NULL,NULL,1),(70,4,9,7,30,11,10,'10',10,1,35,'+28.973',2961073,NULL,0,NULL,NULL,1),(71,4,16,6,88,15,11,'11',11,0,35,'+37.858',2969958,NULL,0,NULL,NULL,1),(72,4,26,2,28,14,12,'12',12,0,34,NULL,NULL,NULL,0,NULL,NULL,2),(73,4,10,1,66,12,13,'13',13,0,34,NULL,NULL,NULL,0,NULL,NULL,3),(74,4,6,5,7,18,14,'14',14,0,33,NULL,NULL,NULL,0,NULL,NULL,3),(75,4,19,9,10,20,NULL,'R',15,0,30,NULL,NULL,NULL,0,NULL,NULL,11),(76,4,1,1,11,5,NULL,'R',16,0,26,NULL,NULL,NULL,0,NULL,NULL,14),(77,4,18,8,9,1,NULL,'R',17,3,23,NULL,NULL,NULL,0,NULL,NULL,12),(78,4,14,9,18,17,NULL,'R',18,0,20,NULL,NULL,NULL,0,NULL,NULL,11),(79,4,5,4,5,10,NULL,'R',19,0,15,NULL,NULL,NULL,0,NULL,NULL,14),(80,4,25,10,77,16,NULL,'D',20,0,35,'+14.724s',2946824,NULL,0,NULL,NULL,15),(81,5,12,8,8,2,1,'1',1,25,39,'46:12.349',2772349,NULL,0,NULL,NULL,1),(82,5,27,2,28,10,2,'2',2,18,39,'+0.433',2772782,NULL,0,NULL,NULL,1),(83,5,10,1,66,4,3,'3',3,15,39,'+5.518',2777867,NULL,0,NULL,NULL,1),(84,5,6,5,7,8,4,'4',4,12,39,'+5.941',2778290,NULL,0,NULL,NULL,1),(85,5,8,6,99,7,5,'5',5,12,39,'+6.426',2778775,NULL,0,NULL,NULL,1),(86,5,21,10,55,16,6,'6',6,8,39,'+8.754',2781103,NULL,0,NULL,NULL,1),(87,5,29,5,6,18,7,'7',7,6,39,'+9.498',2781847,NULL,0,NULL,NULL,1),(88,5,3,3,2,3,8,'8',8,4,39,'+19.817',2792166,NULL,0,NULL,NULL,1),(89,5,1,1,11,6,9,'9',9,2,39,'+20.631',2792980,NULL,0,NULL,NULL,1),(90,5,25,10,77,12,10,'10',10,1,39,'+24.587',2796936,NULL,0,NULL,NULL,1),(91,5,11,3,3,9,11,'11',11,0,39,'+43.883',2816232,NULL,0,NULL,NULL,1),(92,5,13,7,23,19,12,'12',12,0,39,'+47.878',2820227,NULL,0,NULL,NULL,1),(93,5,18,8,9,13,13,'13',13,0,39,'+1:04.587',2836936,NULL,0,NULL,NULL,1),(94,5,5,4,5,20,14,'14',14,0,39,'+1:23.539',2855888,NULL,0,NULL,NULL,1),(95,5,19,9,10,14,15,'15',15,0,38,NULL,NULL,NULL,0,NULL,NULL,2),(96,5,28,9,18,11,16,'16',16,0,38,NULL,NULL,NULL,0,NULL,NULL,2),(97,5,4,6,88,17,17,'17',17,0,38,NULL,NULL,NULL,0,NULL,NULL,2),(98,5,23,2,27,1,18,'18',18,3,37,NULL,NULL,NULL,0,NULL,NULL,3),(99,5,9,7,30,5,NULL,'R',19,0,31,NULL,NULL,NULL,0,NULL,NULL,9),(100,5,20,4,21,15,NULL,'R',20,0,25,NULL,NULL,NULL,0,NULL,NULL,0),(101,6,8,6,99,3,1,'1',1,25,39,'46:01.971',2761971,NULL,0,NULL,NULL,1),(102,6,23,2,27,5,2,'2',2,18,39,'+1.705',2763676,NULL,0,NULL,NULL,1),(103,6,1,1,11,4,3,'3',3,15,39,'+2.994',2764965,NULL,0,NULL,NULL,1),(104,6,18,8,9,10,4,'4',4,12,39,'+3.518',2765489,NULL,0,NULL,NULL,1),(105,6,20,4,21,12,5,'5',5,10,39,'+8.844',2770815,NULL,0,NULL,NULL,1),(106,6,6,5,7,8,6,'6',6,8,39,'+13.460',2775431,NULL,0,NULL,NULL,1),(107,6,21,10,55,7,7,'7',7,6,39,'+16.171',2778142,NULL,0,NULL,NULL,1),(108,6,11,3,3,14,8,'8',8,4,39,'+17.975',2779946,NULL,0,NULL,NULL,1),(109,6,29,5,6,17,9,'9',9,2,39,'+18.436',2780407,NULL,0,NULL,NULL,1),(110,6,9,7,30,9,10,'10',10,1,39,'+20.418',2782389,NULL,0,NULL,NULL,1),(111,6,13,7,23,15,11,'11',11,0,39,'+21.326',2783297,NULL,0,NULL,NULL,1),(112,6,5,4,5,18,12,'12',12,0,39,'+32.917',2794888,NULL,0,NULL,NULL,1),(113,6,28,9,18,20,13,'13',13,0,39,'+38.592',2800563,NULL,0,NULL,NULL,1),(114,6,12,8,8,2,14,'14',14,2,39,'+42.375',2804346,NULL,0,NULL,NULL,1),(115,6,10,1,66,1,15,'15',15,3,39,'+44.361',2806332,NULL,0,NULL,NULL,1),(116,6,4,6,88,16,16,'16',16,0,39,'+58.125',2820096,NULL,0,NULL,NULL,1),(117,6,25,10,77,19,NULL,'R',17,0,27,NULL,NULL,NULL,0,NULL,NULL,11),(118,6,3,3,2,11,NULL,'R',18,0,22,NULL,NULL,NULL,0,NULL,NULL,11),(119,6,19,9,10,13,NULL,'R',19,0,7,NULL,NULL,NULL,0,NULL,NULL,11),(120,6,27,2,28,6,NULL,'R',20,0,3,NULL,NULL,NULL,0,NULL,NULL,11),(121,7,18,8,9,1,1,'1',1,28,47,'48:05.225',2885225,NULL,0,NULL,NULL,1),(122,7,1,1,11,2,2,'2',2,18,47,'+2.154',2887379,NULL,0,NULL,NULL,1),(123,7,8,6,99,4,3,'3',3,15,47,'+4.634',2889859,NULL,0,NULL,NULL,1),(124,7,3,7,2,10,4,'4',4,12,47,'+4.801',2890026,NULL,0,NULL,NULL,1),(125,7,6,5,7,3,5,'5',5,10,47,'+5.881',2891106,NULL,0,NULL,NULL,1),(126,7,12,8,8,6,6,'6',6,8,47,'+11.032',2896257,NULL,0,NULL,NULL,1),(127,7,9,7,30,8,7,'7',7,6,47,'+26.472',2911697,NULL,0,NULL,NULL,1),(128,7,4,6,88,18,8,'8',8,4,47,'+49.538',2934763,NULL,0,NULL,NULL,1),(129,7,21,10,55,19,9,'9',9,2,47,'+52.658',2937883,NULL,0,NULL,NULL,1),(130,7,13,7,23,16,10,'10',10,1,47,'+52.936',2938161,NULL,0,NULL,NULL,1),(131,7,19,9,10,12,11,'11',11,0,47,'+58.984',2944209,NULL,0,NULL,NULL,1),(132,7,27,2,28,13,12,'12',12,0,47,'+1:13.138',2958363,NULL,0,NULL,NULL,1),(133,7,5,4,5,20,13,'13',13,0,46,NULL,NULL,NULL,0,NULL,NULL,2),(134,7,28,9,18,15,NULL,'N',14,0,36,NULL,NULL,NULL,0,NULL,NULL,11),(135,7,23,2,27,11,NULL,'N',15,2,33,NULL,NULL,NULL,0,NULL,NULL,13),(136,7,25,10,77,9,NULL,'N',16,0,28,NULL,NULL,NULL,0,NULL,NULL,13),(137,7,29,5,6,14,NULL,'N',17,0,24,NULL,NULL,NULL,0,NULL,NULL,13),(138,7,10,1,66,5,NULL,'N',18,0,14,NULL,NULL,NULL,0,NULL,NULL,13),(139,7,11,3,3,17,NULL,'R',19,0,0,NULL,NULL,NULL,0,NULL,NULL,13),(140,7,20,4,21,7,NULL,'R',20,0,0,NULL,NULL,NULL,0,NULL,NULL,13),(141,8,6,5,7,6,1,'1',1,25,33,'48:26.566',2906566,NULL,0,NULL,NULL,1),(142,8,18,8,9,3,2,'2',2,18,33,'+2.433',2908999,NULL,0,NULL,NULL,1),(143,8,29,5,6,8,3,'3',3,15,33,'+3.508',2910074,NULL,0,NULL,NULL,1),(144,8,8,6,99,13,4,'4',4,14,33,'+3.975',2910541,NULL,0,NULL,NULL,1),(145,8,13,7,23,4,5,'5',5,10,33,'+13.046',2919612,NULL,0,NULL,NULL,1),(146,8,9,7,30,9,6,'6',6,8,33,'+13.335',2919901,NULL,0,NULL,NULL,1),(147,8,23,2,27,10,7,'7',7,6,33,'+13.678',2920244,NULL,0,NULL,NULL,1),(148,8,3,3,2,15,8,'8',8,4,33,'+14.055',2920621,NULL,0,NULL,NULL,1),(149,8,28,9,18,11,9,'9',9,2,33,'+15.636',2922202,NULL,0,NULL,NULL,1),(150,8,12,8,8,7,10,'10',10,0,33,'+16.602',2923168,NULL,0,NULL,NULL,1),(151,8,21,10,55,19,11,'11',11,0,33,'+16.797',2923363,NULL,0,NULL,NULL,1),(152,8,11,3,3,14,12,'12',12,0,33,'+20.594',2927160,NULL,0,NULL,NULL,1),(153,8,27,2,28,12,13,'13',13,0,33,'+21.149',2927715,NULL,0,NULL,NULL,1),(154,8,10,1,66,5,14,'14',14,0,33,'+23.688',2930254,NULL,0,NULL,NULL,1),(155,8,4,6,88,17,15,'15',15,0,33,'+25.491',2932057,NULL,0,NULL,NULL,1),(156,8,25,10,77,16,16,'16',16,0,33,'+44.157',2950723,NULL,0,NULL,NULL,1),(157,8,20,4,21,18,17,'17',17,0,33,'+46.257',2952823,NULL,0,NULL,NULL,1),(158,8,5,4,5,20,18,'18',18,0,33,'+52.703',2959269,NULL,0,NULL,NULL,1),(159,8,19,9,10,1,19,'19',19,0,31,NULL,NULL,NULL,0,NULL,NULL,3),(160,8,1,1,11,2,NULL,'E',20,0,33,NULL,NULL,NULL,0,NULL,NULL,16),(161,9,8,6,99,2,1,'1',1,25,35,'43:18.867',2598867,NULL,0,NULL,NULL,1),(162,9,1,1,11,3,2,'2',2,18,35,'+2.012',2600879,NULL,0,NULL,NULL,1),(163,9,13,7,23,8,3,'3',3,15,35,'+11.548',2610415,NULL,0,NULL,NULL,1),(164,9,23,2,27,1,4,'4',4,15,35,'+12.416',2611283,NULL,0,NULL,NULL,1),(165,9,10,1,66,7,5,'5',5,10,35,'+25.626',2624493,NULL,0,NULL,NULL,1),(166,9,25,10,77,10,6,'6',6,8,35,'+28.960',2627827,NULL,0,NULL,NULL,1),(167,9,21,10,55,14,7,'7',7,6,35,'+30.529',2629396,NULL,0,NULL,NULL,1),(168,9,12,8,8,6,8,'8',8,4,35,'+31.556',2630423,NULL,0,NULL,NULL,1),(169,9,18,8,9,4,9,'9',9,4,35,'+40.050',2638917,NULL,0,NULL,NULL,1),(170,9,30,2,28,12,10,'10',10,1,35,'+46.320',2645187,NULL,0,NULL,NULL,1),(171,9,6,5,7,5,11,'11',11,0,35,'+51.474',2650341,NULL,0,NULL,NULL,1),(172,9,5,4,5,16,12,'12',12,0,35,'+52.493',2651360,NULL,0,NULL,NULL,1),(173,9,11,3,3,17,13,'13',13,0,35,'+55.810',2654677,NULL,0,NULL,NULL,1),(174,9,9,7,30,20,14,'14',14,0,35,'+56.715',2655582,NULL,0,NULL,NULL,1),(175,9,29,5,6,18,15,'15',15,0,35,'+1:18.763',2677630,NULL,0,NULL,NULL,1),(176,9,20,4,21,15,16,'16',16,0,34,NULL,NULL,NULL,0,NULL,NULL,2),(177,9,28,9,18,19,17,'17',17,0,34,NULL,NULL,NULL,0,NULL,NULL,2),(178,9,19,9,10,9,18,'18',18,3,32,NULL,NULL,NULL,0,NULL,NULL,4),(179,9,24,6,88,13,19,'19',19,0,32,NULL,NULL,NULL,0,NULL,NULL,4),(180,9,3,3,2,11,20,'N',20,0,24,NULL,NULL,NULL,0,NULL,NULL,19),(181,10,18,8,9,1,1,'1',1,28,29,'47:54.784',2874784,NULL,0,NULL,NULL,1),(182,10,6,5,7,2,2,'2',2,18,29,'+0.939',2875723,NULL,0,NULL,NULL,1),(183,10,23,2,27,5,3,'3',3,15,29,'+1.667',2876451,NULL,0,NULL,NULL,1),(184,10,1,1,11,3,4,'4',4,14,29,'+2.409',2877193,NULL,0,NULL,NULL,1),(185,10,8,6,99,4,5,'5',5,10,29,'+7.370',2882154,NULL,0,NULL,NULL,1),(186,10,3,3,2,9,6,'6',6,8,29,'+7.762',2882546,NULL,0,NULL,NULL,1),(187,10,12,8,8,6,7,'7',7,6,29,'+8.553',2883337,NULL,0,NULL,NULL,1),(188,10,29,5,6,11,8,'8',8,4,29,'+9.507',2884291,NULL,0,NULL,NULL,1),(189,10,35,6,88,7,9,'9',9,2,29,'+10.032',2884816,NULL,0,NULL,NULL,1),(190,10,9,7,30,14,10,'10',10,1,29,'+12.077',2886861,NULL,0,NULL,NULL,1),(191,10,33,2,28,16,11,'11',11,0,29,'+15.946',2890730,NULL,0,NULL,NULL,1),(192,10,5,4,5,15,12,'12',12,0,29,'+35.595',2910379,NULL,0,NULL,NULL,1),(193,10,13,7,23,12,13,'13',13,0,29,'+41.034',2915818,NULL,0,NULL,NULL,1),(194,10,31,3,3,19,14,'14',14,0,29,'+42.697',2917481,NULL,0,NULL,NULL,1),(195,10,19,9,10,20,15,'15',15,0,29,'+43.273',2918057,NULL,0,NULL,NULL,1),(196,10,20,4,21,8,16,'16',16,0,29,'+48.423',2923207,NULL,0,NULL,NULL,1),(197,10,25,10,77,10,17,'17',17,0,29,'+1:01.987',2936771,NULL,0,NULL,NULL,1),(198,10,32,9,18,18,NULL,'R',18,0,25,NULL,NULL,NULL,0,NULL,NULL,5),(199,10,10,1,66,13,NULL,'R',19,0,15,NULL,NULL,NULL,0,NULL,NULL,13),(200,10,34,10,55,17,NULL,'R',20,0,15,NULL,NULL,NULL,0,NULL,NULL,21),(201,11,3,3,2,4,1,'1',1,27,29,'45:48.792',2748792,NULL,0,NULL,NULL,1),(202,11,6,5,7,2,2,'2',2,18,29,'+6.973',2755765,NULL,0,NULL,NULL,1),(203,11,29,5,6,3,3,'3',3,15,29,'+9.430',2758222,NULL,0,NULL,NULL,1),(204,11,20,4,21,5,4,'4',4,12,29,'+10.147',2758939,NULL,0,NULL,NULL,1),(205,11,18,8,9,6,5,'5',5,10,29,'+10.689',2759481,NULL,0,NULL,NULL,1),(206,11,1,1,11,11,6,'6',6,8,29,'+11.204',2759996,NULL,0,NULL,NULL,1),(207,11,8,6,99,16,7,'7',7,6,29,'+11.561',2760353,NULL,0,NULL,NULL,1),(208,11,25,10,77,8,8,'8',8,4,29,'+12.402',2761194,NULL,0,NULL,NULL,1),(209,11,35,6,88,12,9,'9',9,2,29,'+14.142',2762934,NULL,0,NULL,NULL,1),(210,11,12,8,8,15,10,'10',10,1,29,'+14.535',2763327,NULL,0,NULL,NULL,1),(211,11,10,1,66,18,11,'11',11,0,29,'+23.170',2771962,NULL,0,NULL,NULL,1),(212,11,33,2,29,13,12,'12',12,0,29,'+24.610',2773402,NULL,0,NULL,NULL,1),(213,11,5,4,5,19,13,'13',13,0,29,'+31.501',2780293,NULL,0,NULL,NULL,1),(214,11,32,9,18,9,14,'14',14,0,29,'+38.423',2787215,NULL,0,NULL,NULL,1),(215,11,9,7,30,1,15,'15',15,3,29,'+48.680',2797472,NULL,0,NULL,NULL,1),(216,11,23,2,27,14,16,'16',16,0,28,NULL,NULL,NULL,0,NULL,NULL,2),(217,11,13,7,23,7,NULL,'R',17,0,17,NULL,NULL,NULL,0,NULL,NULL,7),(218,11,31,3,3,17,NULL,'R',18,0,17,NULL,NULL,NULL,0,NULL,NULL,20),(219,11,19,9,10,10,NULL,'R',19,0,14,NULL,NULL,NULL,0,NULL,NULL,22),(220,11,34,10,55,20,NULL,'R',20,0,6,NULL,NULL,NULL,0,NULL,NULL,13);
/*!40000 ALTER TABLE `results` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seasons`
--

DROP TABLE IF EXISTS `seasons`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seasons` (
  `year` int(11) NOT NULL DEFAULT '0',
  `url` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`year`),
  UNIQUE KEY `url` (`url`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seasons`
--

LOCK TABLES `seasons` WRITE;
/*!40000 ALTER TABLE `seasons` DISABLE KEYS */;
INSERT INTO `seasons` VALUES (2014,'http://en.wikipedia.org/wiki/2014%E2%80%9315_Formula_E_season');
/*!40000 ALTER TABLE `seasons` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `status`
--

DROP TABLE IF EXISTS `status`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `status` (
  `statusId` int(11) NOT NULL AUTO_INCREMENT,
  `status` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`statusId`)
) ENGINE=MyISAM AUTO_INCREMENT=23 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `status`
--

LOCK TABLES `status` WRITE;
/*!40000 ALTER TABLE `status` DISABLE KEYS */;
INSERT INTO `status` VALUES (1,'Finished'),(2,'+1 Lap'),(3,'+2 Laps'),(4,'+3 Laps'),(5,'+4 Laps'),(6,'+5 Laps'),(7,'+6 Laps'),(8,'+7 Laps'),(9,'+8 Laps'),(10,'+9 Laps'),(11,'Retired'),(12,'Collision'),(13,'Accident'),(14,'Suspension'),(15,'Disqualified'),(16,'Excluded'),(17,''),(18,'+10 Laps'),(19,'+11 Laps'),(20,'+12 Laps'),(21,'Battery'),(22,'+15 Laps');
/*!40000 ALTER TABLE `status` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2015-07-03  5:31:26
